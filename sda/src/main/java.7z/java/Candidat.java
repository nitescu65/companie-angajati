public class Candidat {
   private String nume;
    private String pren;
   private  int nivelDeComp;
   private String numeDepartament;

    public String getNume() {
        return nume;
    }

    public void setNume(String nume) {
        this.nume = nume;
    }

    public String getPren() {
        return pren;
    }

    public void setPren(String pren) {
        this.pren = pren;
    }

    public int getNivelDeComp() {
        return nivelDeComp;
    }

    public void setNivelDeComp(int nivelDeComp) {
        this.nivelDeComp = nivelDeComp;
    }

    public String getNumeDepartament() {
        return numeDepartament;
    }

    public void setNumeDepartament(String numeDepartament) {
        this.numeDepartament = numeDepartament;
    }
}
