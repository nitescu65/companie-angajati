public enum StatusCandidat {
    ACCEPTAT,RESPINS,IN_ASTEPTARE
}
