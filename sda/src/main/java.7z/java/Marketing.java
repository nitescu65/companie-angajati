public class Marketing extends Departament implements Evaluator{

    public StatusCandidat evalueaza(Candidat candidat) {
        //to be implements
        return StatusCandidat.ACCEPTAT;
    }

}
