public interface Evaluator {
   public StatusCandidat evalueaza(Candidat candidat);

}
